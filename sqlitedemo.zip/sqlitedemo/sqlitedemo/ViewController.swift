//


import UIKit

class ViewController: UIViewController {

    
    
    
    @IBOutlet weak var emp_name: UITextField!
    
    
    @IBOutlet weak var emp_add: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let obj = dbclass();
        
        var arr = obj.getdata(str: "select * from tbl")
        
        print(arr)
    
    
    }

    @IBAction func insert_click(_ sender: Any) {
        
        let strquery = "insert into tbl(emp_name,emp_add) values ('\(emp_name.text!)','\(emp_add.text!)')";
        
        let obj = dbclass();
        
        var op = obj.dml(str: strquery);
        
        if op == true {
            
            print("sucess")
        
        }
        else{
        
            print("not")
        
        }
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }


}

